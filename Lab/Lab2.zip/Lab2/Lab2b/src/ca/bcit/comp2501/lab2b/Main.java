package ca.bcit.comp2501.lab2b;

/**
 * The driver class for Calendar
 *
 * @author Chris Wu
 * @version 1.0
 */
public class Main
{

    /**
     * The entry point of the program
     */
    public static void main(String[] args)
    {
        Calendar calendar1 = new Calendar();
        calendar1.printCalendar();
    }
}
