package ca.mycalendarproject;

/**
 * This class models a calendar
 * @author jason wilder
 * @version 1.0
 */
public class Calendar
{
    private final String[] daysOfTheWeek;

    public Calendar()
    {
        daysOfTheWeek = new String[7];
        daysOfTheWeek[0] = "sun";
        daysOfTheWeek[1] = "mon";
        daysOfTheWeek[2] = "tue";
        daysOfTheWeek[3] = "wed";
        daysOfTheWeek[4] = "thu";
        daysOfTheWeek[5] = "fri";
        daysOfTheWeek[6] = "sat";

        for(String day: daysOfTheWeek)
        {
            if(day != null)
            {
                System.out.println(day.toUpperCase());
            }
        }
    }

    public static void main(final String[] args)
    {
        Calendar calendar = new Calendar();
    }
}
