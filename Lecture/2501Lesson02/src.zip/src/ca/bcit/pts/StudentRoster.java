package ca.bcit.pts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class StudentRoster
{
    private List<String> studentNames;

    StudentRoster()
    {
        Iterator<String> it;

        studentNames = new ArrayList<>();
        System.out.println(studentNames.size());
        studentNames.add("chris");
        studentNames.add("kyle");
        studentNames.add("elijah");
        studentNames.add(null);
        studentNames.add("haonan");
        studentNames.add("marjan");
        studentNames.add("aaron");
        System.out.println(studentNames.get(1));
        System.out.println(studentNames.size());
        studentNames.remove(1);
        System.out.println(studentNames.size());

        it = studentNames.iterator();
        while(it.hasNext())
        {
            String name;
            name = it.next();
            System.out.println(name);
        }

        for(String name: studentNames)
        {
            System.out.println(name);
        }
    }

    public static void main(final String[] args)
    {
        StudentRoster s = new StudentRoster();

    }
}
