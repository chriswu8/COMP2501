package ca.bcit.pts;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

class CelebrityList{
    private Map<Integer, String> celebrities;
    CelebrityList(){
        celebrities = new HashMap<>();
        // remove(), put(), get(), size()
        celebrities.put(1975, "Angelina Jolie");
        celebrities.put(1976, "Reese Witherspoon");
        celebrities.put(1977, "Kanye West");
        // celebrities.remove(1975);
        System.out.println(celebrities.size());
        System.out.println(celebrities.get(1977));

        Set<Integer> years;
        years = celebrities.keySet();
        for(Integer year: years)
        {
            System.out.println(year + "-->" + celebrities.get(year));
        }

    }
    public static void main(final String[] args)
    {
        CelebrityList celebs;
        celebs = new CelebrityList();
    }
}
