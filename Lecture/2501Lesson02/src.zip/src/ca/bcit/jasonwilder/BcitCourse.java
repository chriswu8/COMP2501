package ca.bcit.jasonwilder;

/**
 * models a BCIT course
 * @author jason wilder
 * @version 1.0
 */
class BcitCourse
{
    private String[] studentNames;

    BcitCourse()
    {
        studentNames = new String[21];

        studentNames[0]  = "samuel";
        studentNames[17] = "ee von";
        studentNames[3]  = "kevin";

        for(String name: studentNames)
        {
            if(name != null)
            {
                System.out.println(name);
            }
        }

        int i;
        i = 0;
        while(i < studentNames.length)
        {
            if(studentNames[i] != null)
            {
                System.out.println(studentNames[i]);
            }
            i += 1;
        }
    }
}
