package ca.bcit.jasonwilder;

public class Main
{
    public static void main(final String[] args)
    {
        //BcitCourse c;
        //c = new BcitCourse();

    }
}
